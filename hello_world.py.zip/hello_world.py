# 1. TASK: print "Hello World"
print("Hello World")

# 2. print "Hello Spencer!" with the name in a variable
name = "spencer"
print("Hello" + name)
print("Hello", name)

# 3. print "Hello 2!" with the number in a a variable
name = 2
print("Hello", name)
print("Hello" + str(name))

# 4. print "I love to eat sushi and pizza." with the foods in variables
fave_food1 = "pizza"
fave_food2 = "wings"
print("I love to eat {} and {}!".format(fave_food1, fave_food2))
# print(f"I love to eat {fave_food1} and {fave_food2}")

print("i am bigger".islower())
